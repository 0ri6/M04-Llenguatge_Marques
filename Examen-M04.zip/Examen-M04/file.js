document.addEventListener('DOMContentLoaded', function (){
    document.querySelector('.text').addEventListener('click', function (){
        this.innerHTML += '👏';
    });
});

